import tkinter as tk
from tkinter import ttk
import files.modules.values as values
import files.modules.fileroutes as fileroutes

items_guardroom=['man','guard','guy','water','river','stream','fire','fireplace','floor','wall','walls','ceiling','table','door','dice']
guard_words=['man','guard','guy']
water_words=['river','water','stream']
wall_words=['ceiling','wall','walls','floor']

def check_door(b):

    if values.door_easthall:
        b.insert(tk.END, "It is a sturdy wooden door.")
    else:
        b.insert(tk.END, "The door is open. Peering through, you can see a large ")
        if values.monster:
            b.insert(tk.END, "hulking creature in the next room.")
        else:
            b.insert(tk.END, "empty room.")

def check_man(b):

    if values.guard:
        b.insert(tk.END, "He is a bearded man wearing a dirty brown uniform and a small sword on his belt. He sits at the table idly playing with a set of dice.")
    else:
        for i in guard_words:
            items_guardroom.remove(i)
        for n in ('sword','jewel','coin','coins','key','uniform','clothes'):
            items_guardroom.append(n)
        b.insert(tk.END, "You cannot tell if he is dead or merely unconscious, but you suspect the former. "+
                         "In the pockets of his uniform are a gold key, a shiny yellow jewel, and seven gold coins. "+
                         "His sword is still in his hands.")

def check_water(b):

    for i in water_words:
        items_guardroom.remove(i)
    items_guardroom.append('jewel')
    b.insert(tk.END, "You peer into the rushing water and spy a beautiful little jewel nestled between two rocks.")

def check_table(b):

    items_guardroom.remove('table')
    items_guardroom.append('apple')
    b.insert(tk.END, "You spy a delectable-looking red apple on the table.")
    if values.guard:
        b.insert(tk.END, " Noticing your gaze, the man nods at it, as if giving you permission to take it.")

def check_apple(b):

    b.insert(tk.END, "You should take the apple if you wish to examine it.")

def check_jewel(b):

    b.insert(tk.END, "You should take the jewel if you wish to examine it.")

def check_fire(b):

    b.insert(tk.END, "The fire burns low, but keeps you warm.")

check_dict={'door':check_door, 'fire':check_fire, 'fireplace':check_fire, 'jewel':check_jewel, 'man':check_man, 'guard':check_man,
            'guy':check_man, 'body':check_man, 'corpse':check_man, 'river':check_water, 'water':check_water, 'stream':check_water, 'table':check_table, 'apple':check_apple}

def take_jewel(b):

    values.jewel_clear()
    items_guardroom.remove('jewel')
    values.inventory_lower.append('jewel')
    values.inventory.append('Jewel')
    b.insert(tk.END, "Taken.")

def take_apple(b):

    items_guardroom.remove('apple')
    values.inventory_lower.append('apple')
    values.inventory.append('Apple')
    b.insert(tk.END, "Taken.")

def take_uniform(b):

    for i in ('uniform','clothes'):
        items_guardroom.remove(i)
        if i=='uniform':
            values.inventory_lower.append(i)
            values.inventory.append(str.capitalize(i))
    b.insert(tk.END, "Taken. You hesitantly put it on. It reeks of beer and blood, but the dark color hides the stains well enough. "+
                     "It may come in handy to look like a guard.")

def take_coins(b):

    values.coin_clear()
    for i in ('coin','coins'):
        items_guardroom.remove(i)
    for k in range(1,8):
        values.inventory_lower.append('coin')
        values.inventory.append('Coin')
    b.insert(tk.END, "Taken.")

def take_sword(b):

    items_guardroom.remove('sword')
    values.inventory_lower.append('sword')
    values.inventory.append('Sword')
    b.insert(tk.END, "Taken.")

def take_key(b):

    items_guardroom.remove('key')
    values.inventory_lower.append('gold key')
    values.inventory.append('Gold Key')
    b.insert(tk.END, "Taken.")

take_dict={'key':take_key, 'sword':take_sword, 'uniform':take_uniform, 'clothes':take_uniform, 'jewel':take_jewel,
           'apple':take_apple, 'coin':take_coins, 'coins':take_coins}

def guard_attack(b):

    weapon=0
    values.guard=False
    values.door_guardroom.clear()
    if values.door_easthall:
        values.door_guardroom.append('noguard')
    else:
        values.door_guardroom.append('noguardnodoor')
    for k in (items_guardroom, guard_words):
        k.append('body')
        k.append('corpse')
    for i in values.inventory_lower:
        if i in ('dagger','sword'):
            weapon+=values.weapon_dict[i]
    attack_dict={0:"You try to punch him, but he is ready for you and deftly avoids the hit.",
                 1:"You try to cut him with your dagger, but he is ready for you and deftly avoids the hit.",
                 2:"You try to cut him with your dagger, but he is ready for you and deftly avoids the hit.",
                 3:"You try to cut him with your sword, but he is ready for you and deftly avoids the hit.",
                 4:"You try to cut him with your sword, but he is ready for you and deftly avoids the hit.",
                 5:"You try to cut him with your sword, but he is ready for you and deftly avoids the hit."}
    health_loss={0:3, 1:2, 2:2, 3:1, 4:1, 5:1}
    outcome_dict={0:"Your bare hands are no match for a sword. He hurts you badly before you manage to knock him out with a lucky punch.\n\nYou lose three bars of health.",
                  1:"Your dagger is helpful, but it's not as good as a sword. You manage to kill him, but not before being cut deeply yourself.\n\nYou lose two bars of health.",
                  2:"Your dagger is helpful, but it's not as good as a sword. You manage to kill him, but not before being cut deeply yourself.\n\nYou lose two bars of health.",
                  3:"Your fight is short and nasty. You are, surprisingly, better with a sword than he is, and you take only a small wound before dispatching him.\n\nYou lose one bar of health.",
                  4:"Your fight is short and nasty. You are, surprisingly, better with a sword than he is, and you take only a small wound before dispatching him.\n\nYou lose one bar of health.",
                  5:"Your fight is short and nasty. You are, surprisingly, better with a sword than he is, and you take only a small wound before dispatching him.\n\nYou lose one bar of health."}
    values.health-=health_loss[weapon]
    b.insert(tk.END, attack_dict[weapon]+" ")
    b.insert(tk.END, fileroutes.guard_attack+" ")
    b.insert(tk.END, outcome_dict[weapon])

def choice_guardroom(b,c,d):

    if d in items_guardroom or c=='dice':

        if c in ('fight','punch','kick','attack','hit','break','kill') and d not in water_words+['dice']:
            if d not in guard_words:
                if c in ('attack','break'):
                    c='hit'
                values.health-=1
                b.insert(tk.END, "You " + c + " the " + d + " and hurt yourself.\n\nYou lose one bar of health.")
            if d in guard_words:
                guard_attack(b)

        if c in ('check','examine','inspect','search'):
            if d not in wall_words:
                check_dict[d](b)
            else:
                b.insert(tk.END, "You "+c+" the "+d+" and find nothing of significance.")

        if c in ('take','grab','get'):
            take_dict[d](b)

        if c in ('open', 'unlock', 'use') and d=='door' and values.door_easthall:
            if values.guard:
                values.door_easthall=False
                values.door_guardroom.clear()
                values.door_guardroom.append('open')
                values.torch.clear()
                values.torch.append('notorch_open')
                b.insert(tk.END, fileroutes.guard_open_door)
                if values.monster:
                    b.insert(tk.END, " Through the open door you can see a large, hulking figure in the next room.")
            else:
                if 'key' in values.inventory_lower:
                    b.insert(tk.END, "The rusty key doesn't fit the lock. ")
                if c=='unlock' and 'gold key' in values.inventory_lower:
                    values.inventory_lower.remove('gold key')
                    values.inventory.remove('Gold Key')
                    values.door_easthall = False
                    values.door_guardroom.clear()
                    values.door_guardroom.append('noguardnodoor')
                    b.insert(tk.END, "The gold key fits perfectly. As it swings open, your key snaps in the lock.")
                else:
                    b.insert(tk.END, "The door is locked.")

    if 'dice' in (c,d) or c=='play':
        if values.guard:
            b.insert(tk.END, "(Type a command to continue)")
            values.sequence.append('dice_game')
        else:
            b.insert(tk.END, "With who? The man you killed?")

    if c in ('talk','speak','say','ask'):
        if values.guard:
            if not values.guard_talk:
                values.guard_talk=True
                b.insert(tk.END, fileroutes.guard_talk)
            else:
                b.insert(tk.END, fileroutes.guard_talk_2)
        else:
            b.insert(tk.END, "You apologize to his corpse. It's a bit therapeutic, in a macabre sort of way.")
