import tkinter as tk
from tkinter import ttk
import files.modules.fileroutes as fileroutes
import files.modules.values as values

items_basement=['body','corpse','tunnel','figures','people','shrine','statue','altar','wall','walls','ceiling','floor','s','south']

def go_south(b):

    b.insert(tk.END, "You head into the south tunnel.")
    values.sequence.append('south')

def check_body(b):

    if 'lockbox' in values.inventory_lower or 'note 2' in values.inventory_lower:

        b.insert(tk.END, "The body appears to be fresh.")

    else:

        b.insert(tk.END, "The body appears to be fresh. In his hands is a closed lockbox.")

        if 'lockbox' not in items_basement:

            items_basement.append('lockbox')

def check_lockbox(b):

    b.insert(tk.END, "You will have to take the lockbox if you wish to examine it.")

def check_figures(b):

    b.insert(tk.END, "The figures are still chanting. They make you uneasy.")

def check_tunnel(b):

    b.insert(tk.END, "The tunnel is absolutely squalid, but it appears to have some light coming from the end of it. "+
             "Upon closer inspection, you see sloppy brown writing on the wall next to it that reads "+'"The light is a lie".')

def check_shrine(b):

    b.insert(tk.END, "It appears to be a shrine to a deity that you do not recognize.")

check_dict={'shrine':check_shrine, 'statue':check_shrine, 'altar':check_shrine, 'tunnel':check_tunnel, 'figures':check_figures, 'people':check_figures, 'lockbox':check_lockbox, 'body':check_body, 'corpse':check_body}

def choice_basement(b,c,d):

    if d in items_basement+['']:

        if d=='key' and 'lockbox' in items_basement:
            b.insert(tk.END, "You might want to take the lockbox before trying to use the key on it.")

        if d in ('figures','people') and c not in ('check','examine','inspect','search'):
            b.insert(tk.END, "You will have to go east to interact with the figures. Your gut tells you that it may not"+
                             " be a great idea.")

        if c in ('punch','kick','attack','hit','break') and d not in ('people','figures','s','south'):
            if c in ('attack','break'):
                c='hit'
            values.health-=1
            b.insert(tk.END, "You " + c + " the " + d + " and hurt yourself.\n\nYou lose one bar of health.")

        if c in ('check','examine','inspect','search','open'):
            if d in ('wall','walls','ceiling','floor'):
                b.insert(tk.END, "You "+c+" the "+d+" and find nothing of significance.")
            else:
                check_dict[d](b)

        if c in ('take','grab','get') and d=='lockbox':
            if 'lockbox' not in values.inventory_lower and 'note 2' not in values.inventory_lower:
                values.inventory_lower.append('lockbox')
                values.inventory.append('Lockbox')
                b.insert(tk.END, "Taken.")

        if c in ('pray','worship'):
            for i in ('shrine', 'statue', 'altar'):
                if i in items_basement:
                    items_basement.remove(i)
            b.insert(tk.END, "(Type a command to continue)")
            values.sequence.append('prayer')
