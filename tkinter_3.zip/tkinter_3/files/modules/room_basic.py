import tkinter as tk
from tkinter import ttk
import files.modules.fileroutes as fileroutes
from files.modules.room_config import room_configure
from files.modules.player_choice import choices
import files.modules.values as values
from files.modules.death import death
import random

class room(tk.Frame):

    def __init__(self, parent, controller):

        def look_button(a):

            textbox.configure(state='normal')
            textbox.insert(tk.END, '\n\n')
            a(textbox,'l',' ')
            textbox.see('end')
            textbox.configure(state='disabled')
            room_configure(label, image_label, inventory_label, health_bar, button_top, button_left, button_right,
                           button_bottom, textbox, button_look, entrybox, prompt, minimap_label, icon_label, enemy_label)

        def get_input(event):

            if values.health<=0:
                controller.show_frame(death)

            sequence_dict = {'dice_game':dice_game, 'question': question, 'prayer':prayer, 'monster_talk':speak_monster,
                             'riddles':riddles}
            answer=entrybox.get()
            entrybox.delete(0, 'end')
            choices(answer, textbox)
            room_configure(label, image_label, inventory_label, health_bar, button_top, button_left,
                           button_right, button_bottom, textbox, button_look, entrybox, prompt, minimap_label,
                           icon_label, enemy_label)

            if values.sequence:
                controller.show_frame(sequence_dict[values.sequence[0]])
                values.sequence.clear()
            
        tk.Frame.__init__(self, parent)
        self.configure(background='black')
        self.grid_columnconfigure(0, weight=1)
        self.grid_columnconfigure(2, weight=1)
        label=tk.Label(self, bg='black', fg='white', font=controller.large_font)
        
        textbox=tk.Text(self, bg="black", fg="white", bd=0, width=120, height=10, font=controller.smol_font,
                        insertbackground='white', wrap='word')
        textbox.insert(tk.END, fileroutes.start_room_text)
        textbox.configure(state='disabled')

        basic_commands=tk.Text(self, bg="black", fg="white", bd=3, width=10, height=10, font=controller.smol_font)
        basic_commands.insert(tk.END, "Basic\nCommands:\ncheck x\nuse x\ntake x\nlook\nnorth\nsouth\neast\nwest")
        basic_commands.configure(state='disabled')
        
        scrollbar=tk.Scrollbar(self, command=textbox.yview)
        textbox['yscrollcommand']=scrollbar.set
        prompt=tk.Label(self, text='What would you like to do?: ', bg='black', fg='white')
        entrybox=tk.Entry(self, bg='black', fg='white', width=108)
        entrybox.bind('<Return>', get_input)
        
        button_top=ttk.Button(self, width=7)
        button_left=ttk.Button(self, width=7)
        button_right=ttk.Button(self, width=7)
        button_bottom=ttk.Button(self, width=7)
        button_look=ttk.Button(self, width=7, text='Look', command=lambda: look_button(values.look))

        minimap_photo=tk.PhotoImage(file=fileroutes.minimap_room1)
        image_label=tk.Label(self, bg='black', bd=0)
        minimap_label = tk.Label(self, bd=0, image=minimap_photo)
        minimap_label.image=minimap_photo
        icon_photo = tk.PhotoImage(file=fileroutes.player_icon)
        icon_label = tk.Label(self, bd=0, image=icon_photo)
        icon_label.image = icon_photo
        enemy_photo=tk.PhotoImage(file=fileroutes.enemy_icon)
        enemy_label=tk.Label(self, bd=0, image=enemy_photo)
        enemy_label.image=enemy_photo
        inventory_label=tk.Label(self, bg='black', fg='white', font=("Verdana",11))
        health_bar=tk.Label(self, bg='black', bd=0)

        label.grid(row=0, column=1, pady=10)
        button_top.grid(row=2, column=1)
        health_bar.grid(row=2, column=1, sticky='w')
        button_left.grid(row=3, column=0, padx=20)
        image_label.grid(row=3, column=1, pady=10)
        minimap_label.place(in_=image_label, anchor='nw')
        icon_label.place(in_=minimap_label, x=45, y=90)
        button_right.grid(row=3, column=2, padx=20)
        button_bottom.grid(row=4, column=1, pady=10)
        button_look.grid(row=5, column=1, pady=10)
        inventory_label.grid(row=6, column=1, sticky='w')
        textbox.grid(row=7, column=1)
        scrollbar.grid(row=7, column=2, sticky='nsw')
        basic_commands.grid(row=7, column=0, sticky='nse', padx=20)
        prompt.grid(row=8, column=1, sticky='w')
        entrybox.grid(row=8, column=1, sticky='e')
        room_configure(label, image_label, inventory_label, health_bar, button_top, button_left, button_right,
                       button_bottom, textbox, button_look, entrybox, prompt, minimap_label, icon_label, enemy_label)

class question(tk.Frame):

    def __init__(self, parent, controller):

        def health_func():

            for i in (yes, no):

                i.destroy()

            values.health+=1
            hw_label.configure(text=fileroutes.get_health)
            hw_label.grid(row=3, column=1, pady=50)
            cont_button.grid(row=4, column=1, pady=50)

        def wealth_func():

            for i in (yes, no):
                i.destroy()
                
            values.jewel_clear()
            values.inventory.append('Jewel')
            values.inventory_lower.append('jewel')
            hw_label.configure(text=fileroutes.get_jewel)
            hw_label.grid(row=3, column=1, pady=50)
            cont_button.grid(row=4, column=1, pady=50)

        def no_func():
            
            values.health-=2
            values.no=True
            response_label.configure(text=fileroutes.shadow_no)
            response_label.grid(row=2, column=1)
            
            for i in (yes, no):

                i.destroy()
  
            cont_button.grid(row=4, column=1, pady=50)

        def yes_func():

            response_label.configure(text=fileroutes.shadow_yes)
            response_label.grid(row=2, column=1, pady=50)
            no.configure(text='Wealth', command=lambda: wealth_func())
            yes.configure(text='Health', command=lambda: health_func())
            
        frame_dict={-2:death, -1:death, 0:death, 1:room, 2:room, 3:room, 4:room, 5:room, 6:room, 7:room}
        tk.Frame.__init__(self, parent)
        self.configure(background='black')
        self.grid_columnconfigure(0, weight=1)
        self.grid_columnconfigure(2, weight=1)
        
        title=tk.Label(self, bg='black', fg='white', bd=0, font=controller.large_font, text='A Dark Place')
        #image_label=tk.Label(self, bg='black', fg='white', bd=0)
        label=tk.Label(self, bg='black', fg='white', bd=0, font=controller.med_font, text=fileroutes.shadow_response)
        response_label=tk.Label(self, bg='black', fg='white', bd=0, font=controller.med_font)
        hw_label=tk.Label(self, bg='black', fg='white', bd=0, font=controller.med_font)
        
        no=ttk.Button(self, text='No', command=lambda: no_func())
        yes=ttk.Button(self, text='Yes', command=lambda: yes_func())
        cont_button=ttk.Button(self, text='Continue', command=lambda: controller.show_frame(frame_dict[values.health]))

        title.grid(row=0, column=1, pady=10)
        label.grid(row=1, column=1, pady=40, sticky='w')
        yes.grid(row=4, column=1, sticky='w')
        no.grid(row=4, column=1, sticky='e')

class riddles(tk.Frame):

    def __init__(self, parent, controller):

        def get_input(event):

            if values.health<=0:
                controller.show_frame(death)
            if max(values.riddle_count)>=4:
                values.sequence.clear()
                controller.show_frame(treasure)
            answer = str.lower(entrybox.get())
            entrybox.delete(0, 'end')
            textbox.configure(state='normal')
            textbox.insert(tk.END, "\n\n"+answer)
            if values.riddle_count:
                values.riddles_func(answer, textbox)
            if values.health<=0 or max(values.riddle_count)>=4:
                textbox.insert(tk.END, "\n\n(Type a command to continue)")
                
            textbox.see('end')
            textbox.configure(state='disabled')

        def cont_2():

            cont_button.grid_forget()
            textbox.configure(state='normal')
            values.riddles_func(' ', textbox)
            entrybox.grid(row=4, column=1)
            textbox.see('end')
            textbox.configure(state='disabled')

        def cont_1():

            cont_button.configure(command=lambda: cont_2())
            textbox.configure(state='normal')
            textbox.insert(tk.END, '\n\n"Very well. I will pose to you three riddles, and you must answer all in kind. Answer'+
                           ' incorrectly and you will pay dearly..."')
            textbox.see('end')
            textbox.configure(state='disabled')

        tk.Frame.__init__(self, parent)
        self.configure(background='black')
        self.grid_columnconfigure(0, weight=1)
        self.grid_columnconfigure(2, weight=1)

        photo=tk.PhotoImage(file=fileroutes.statue_zoomed_image)
        label = tk.Label(self, bg='black', fg='white', font=controller.large_font, text='Dark Room')
        image_label = tk.Label(self, bg='black', bd=0)
        image_label.configure(image=photo)
        image_label.image=photo
        textbox = tk.Text(self, bg="black", fg="white", bd=0, width=120, height=10, font=controller.smol_font,
                          wrap='word')
        textbox.insert(tk.END, fileroutes.statue_firsttalk)
        textbox.configure(state='disabled')
        scrollbar = tk.Scrollbar(self, command=textbox.yview)
        textbox['yscrollcommand'] = scrollbar.set
        entrybox = tk.Entry(self, bg='black', fg='white', width=140)
        entrybox.bind('<Return>', get_input)
        cont_button=ttk.Button(self, width=9, text='Continue', command=lambda: cont_1())

        label.grid(row=0, column=1, pady=10)
        image_label.grid(row=1, column=1)
        cont_button.grid(row=2, column=1, pady=10)
        textbox.grid(row=3, column=1, pady=10)
        scrollbar.grid(row=3, column=2, sticky='nsw')

class treasure(tk.Frame):

    def __init__(self, parent, controller):

        def cont_2():

            label.configure(text='Mountain Top')
            textbox.configure(state='normal')
            textbox.insert(tk.END, '\n\n' + fileroutes.treasure[456:]+'\n\nYour adventure is over. You are free.')
            textbox.configure(state='disabled')
            textbox.see('end')
            photo_3 = tk.PhotoImage(file=fileroutes.escape_image)
            image_label.configure(image=photo_3)
            image_label.image = photo_3
            cont_button.destroy()

        def cont_1():

            textbox.configure(state='normal')
            textbox.insert(tk.END,'\n\n'+fileroutes.treasure[0:456])
            textbox.configure(state='disabled')
            textbox.see('end')
            photo_2=tk.PhotoImage(file=fileroutes.treasure_room_image)
            image_label.configure(image=photo_2)
            image_label.image=photo_2
            cont_button.configure(command=lambda: cont_2())

        tk.Frame.__init__(self, parent)
        self.configure(background='black')
        self.grid_columnconfigure(0, weight=1)
        self.grid_columnconfigure(2, weight=1)
        label = tk.Label(self, bg='black', fg='white', font=controller.large_font, text='Hidden Room')
        photo=tk.PhotoImage(file=fileroutes.treasure_reveal_image)
        image_label = tk.Label(self, bg='black', bd=0, image=photo)
        image_label.image=photo
        cont_button=ttk.Button(self, width=9, text='Continue', command=lambda: cont_1())
        textbox=tk.Text(self, bg="black", fg="white", bd=0, width=120, height=10, font=controller.smol_font,
                        wrap='word')
        textbox.insert(tk.END, fileroutes.riddles_solved)
        textbox.configure(state='disabled')
        textbox.see('end')
        label.grid(row=0, column=1, pady=10)
        image_label.grid(row=1, column=1)
        cont_button.grid(row=2, column=1, pady=10)
        textbox.grid(row=3, column=1, pady=10)

class prayer(tk.Frame):

    def __init__(self, parent, controller):

        def yes():

            values.jewel_clear()
            values.coin_clear()
            values.health-=2
            for i in (button_yes, button_no):
                i.destroy()
            for i in ('sword','jewel'):
                values.inventory_lower.append(i)
                values.inventory.append(str.capitalize(i))
            for i in range(1,16):
                values.inventory_lower.append('coin')
                values.inventory.append('Coin')
            textbox.configure(state='normal')
            textbox.insert(tk.END, '\n\n' + fileroutes.shrine_yes)
            textbox.configure(state='disabled')
            textbox.see('end')
            cont_button = ttk.Button(self, width=12, text="Continue", command=lambda: controller.show_frame(room),
                                     wrap='word')
            cont_button.grid(row=3, column=1, pady=30)

        def no():

            textbox.configure(state='normal')
            textbox.insert(tk.END, '\n\n'+fileroutes.shrine_no)
            textbox.configure(state='disabled')
            textbox.see('end')
            for i in (button_yes, button_no):
                i.destroy()
            cont_button=ttk.Button(self, width=12, text="Continue", command=lambda: controller.show_frame(room))
            cont_button.grid(row=3, column=1, pady=30)

        tk.Frame.__init__(self, parent)
        self.configure(background='black')
        self.grid_columnconfigure(0, weight=1)
        self.grid_columnconfigure(2, weight=1)
        photo=tk.PhotoImage(file=fileroutes.shrine_image)

        title=tk.Label(self, bg='black', fg='white', bd=0, font=controller.large_font, text='Shrine')
        image_label=tk.Label(self, bg='black', fg='white', bd=0, image=photo)
        image_label.image=photo

        textbox=tk.Text(self, bg='black', fg='white', bd=0, font=controller.med_font, height=9, width=100)
        textbox.insert(tk.END, fileroutes.pray)
        textbox.configure(state='disabled')
        textbox.see('end')

        button_yes=ttk.Button(self, width=10, text='Yes', command=lambda: yes())
        button_no=ttk.Button(self, width=10, text='No', command=lambda: no())

        title.grid(row=0, column=1, pady=10)
        image_label.grid(row=1, column=1, pady=20)
        textbox.grid(row=2, column=1)
        button_yes.grid(row=3, column=1, sticky='nw', pady=30)
        button_no.grid(row=3, column=1, sticky='ne', pady=30)

class speak_monster(tk.Frame):

    def __init__(self, parent, controller):

        def yes():

            values.inventory_lower.append('vial')
            values.inventory.append('Vial')
            no_button.destroy()
            yes_button.destroy()
            cont_button.grid(row=3, column=1)
            cont_button.configure(command=lambda: controller.show_frame(room))
            textbox.configure(state='normal')
            textbox.insert(tk.END, "\n\nYes\n\n"+fileroutes.give_gem)
            textbox.configure(state='disabled')
            textbox.see('end')

        def no():

            values.health-=2
            no_button.destroy()
            yes_button.destroy()
            cont_button.grid(row=3, column=1)
            cont_button.configure(command=lambda: controller.show_frame(room))
            textbox.configure(state='normal')
            textbox.insert(tk.END, "\n\nNo\n\n"+fileroutes.deny_jewel+"\n\nYou lose two bars of health.")
            textbox.configure(state='disabled')
            textbox.see('end')

        def jewel():

            textbox.configure(state='normal')
            if 'jewel' in values.inventory_lower or 'Jewel' in values.inventory:
                #if 'Jewel' in values.inventory:
                #   values.inventory.remove('Jewel')
                values.jewel_clear()
                #values.inventory_lower.remove('jewel')
                values.jewel_decrease()
                cont_button.grid_forget()
                textbox.insert(tk.END, "\n\nWill you give him the jewel in your pocket?")
                yes_button.grid(row=3, column=1, sticky='w')
                no_button.grid(row=3, column=1, sticky='e')
            else:
                values.health-=2
                cont_button.configure(command=lambda: controller.show_frame(room))
                textbox.insert(tk.END, "\n\n"+fileroutes.monster_nojewel+"\n\nYou lose two bars of health.")
            textbox.configure(state='disabled')
            textbox.see('end')

        tk.Frame.__init__(self, parent)
        self.configure(background='black')
        self.grid_columnconfigure(0, weight=1)
        self.grid_columnconfigure(2, weight=1)

        photo=tk.PhotoImage(file=fileroutes.talk_monster_image)
        image_label = tk.Label(self, bg = 'black', image=photo, bd=0)
        image_label.image=photo

        label = tk.Label(self, bg='black', fg='white', font=controller.large_font, text="East Hall")
        textbox = tk.Text(self, bg="black", fg="white", bd=0, width=100, height=10, font=controller.med_font,
                          wrap='word')
        textbox.insert(tk.END, fileroutes.monster_jewel)
        textbox.configure(state='disabled')
        textbox.see('end')

        yes_button=ttk.Button(self, text="Yes", command=lambda: yes())
        no_button=ttk.Button(self, text="No", command=lambda: no())
        cont_button=ttk.Button(self, text="Continue", command=lambda:jewel())

        label.grid(row=0, column=1, pady=20)
        image_label.grid(row=1, column=1, pady=20)
        textbox.grid(row=2, column=1, pady=20)
        cont_button.grid(row=3, column=1)

class dice_game(tk.Frame):

    def __init__(self, parent, controller):

        def cont_func():

            textbox.configure(state='normal')
            textbox.insert(tk.END, "\n\n"+fileroutes.dice_explain)
            textbox.see('end')
            textbox.configure(state='disabled')
            for z in (cont, slider, prompt, q, answer):
                z.grid_forget()
            q.grid(row=3, column=1, pady=20)
            yes.grid()
            no.grid()
            controller.show_frame(room)

        def yes_func():

            if values.inventory_lower.count('coin')==0:
                yes.grid_remove()
                no.grid_remove()
                answer.grid(row=4, column=1)
                cont.grid(row=5, column=1, sticky='n', pady=20)
            else:
                slider.configure(from_=1, to=values.inventory_lower.count('coin'))
                yes.grid_remove()
                no.grid_remove()
                prompt.grid(row=4, column=1)
                slider.grid(row=5, column=1, sticky='n', pady=20)
                play.grid(row=6, column=1, sticky='n')

        def play_func():

            gamble=slider.get()
            play.grid_remove()
            q.grid_remove()
            prompt.grid_remove()
            slider.grid_remove()
            player_score=0
            guard_score=0
            player_roll=random.choices(range(1,7), k=5)
            guard_roll=random.choices(range(1,7), k=5)
            for i in range(1,7):
                if player_roll.count(i)==0:
                    player_score+=1
                if player_roll.count(i)==1:
                    player_score+=i
                else:
                    j=i**player_roll.count(i)
                    player_score+=j
            for k in range(1,7):
                if guard_roll.count(k)==0:
                    guard_score+=1
                if guard_roll.count(k)==1:
                    guard_score+=k
                else:
                    m=k**guard_roll.count(k)
                    guard_score+=m
            textbox.configure(state='normal')
            textbox.insert(tk.END, "\n\nYou roll "+str(player_roll)+" and your total score is "+str(player_score)+
                           ".\nThe man rolls "+str(guard_roll)+" and his total score is "+str(guard_score)+".")
            if player_score==guard_score:
                textbox.insert(tk.END, "\n\n"+fileroutes.dice_tie)
            if player_score>guard_score:
                values.coin_clear()
                for h in range(1, gamble+1):
                    values.inventory_lower.append('coin')
                    values.inventory.append('Coin')
                textbox.insert(tk.END, "\n\n"+fileroutes.dice_win)
            if player_score<guard_score:
                values.coin_clear()
                for y in range(1, gamble+1):
                    values.coin_decrease()
                textbox.insert(tk.END, "\n\n"+fileroutes.dice_lose)
            if values.inventory_lower.count('coin')==0:
                values.coin_clear()
            yes.grid()
            no.grid()
            textbox.see('end')
            textbox.configure(state='disabled')

        tk.Frame.__init__(self, parent)
        self.configure(background='black')
        self.grid_columnconfigure(0, weight=1)
        self.grid_columnconfigure(2, weight=1)
        title = tk.Label(self, bg='black', fg='white', font=controller.large_font, text="Small Table")

        photo=tk.PhotoImage(file=fileroutes.dice_image)
        image_label=tk.Label(self, bg="black", fg='white', bd=0, image=photo)
        image_label.image=photo

        textbox = tk.Text(self, bg="black", fg="white", bd=0, width=120, height=4, font=controller.med_font,
                          wrap='word')
        textbox.insert(tk.END, fileroutes.dice_explain)
        textbox.see('end')
        textbox.configure(state='disabled')

        q=tk.Label(self, bg="black", fg='white', bd=0, text="Would you like to play?", font=controller.med_font)
        answer=tk.Label(self, bg="black", fg="white", bd=0, text="You don't have any money to play with!", font=controller.med_font)
        prompt=tk.Label(self, bg='black', fg='white', bd=0, text="How many coins would you like to bet?", font=controller.med_font)

        cont=ttk.Button(self, text='Continue', command=lambda: cont_func())
        no=ttk.Button(self, text='No', command=lambda: cont_func())
        yes=ttk.Button(self, text='Yes', command=lambda: yes_func())
        play=ttk.Button(self, text='Throw the dice!', command=lambda: play_func())

        slider=tk.Scale(self, orient='horizontal', bg='black', fg='white', bd=0, font=controller.med_font)

        title.grid(row=0, column=1, pady=10)
        image_label.grid(row=1, column=1, pady=10)
        textbox.grid(row=2, column=1, pady=10)
        q.grid(row=3, column=1, pady=20)
        yes.grid(row=5, column=1, sticky='w', padx=150)
        no.grid(row=5, column=1, sticky='e', padx=150)
