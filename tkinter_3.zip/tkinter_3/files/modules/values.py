import tkinter as tk
from tkinter import ttk
import collections
import files.modules.fileroutes as fileroutes
from files.modules.death import death
import random

#fix easthall coming from guard room

location='Room1'
health=5
inventory_lower=[]
cancel=[]
inventory=[]
inventory_func='Inventory:',inventory
door1=[]
door_guardroom=['closed']
sound='present'
westhall_north=False
#monster='present'
#question=False
no=False
monster=True
torch=['unlit']
door_easthall=True
before_basement=[]
sequence=[]
weapon_dict={'dagger':1,'sword':3}
weapons=0
guard=True
guard_talk=False
big_man=['alive']
statue_jewels=0
riddle_count=[0]
riddle_choice=[]
minimap_counter=[0]
minimap_counter_two=[0]

health_bar={-2: fileroutes.health_bar_0, -1: fileroutes.health_bar_0, 0: fileroutes.health_bar_0, 1: fileroutes.health_bar_1,
            2: fileroutes.health_bar_2, 3: fileroutes.health_bar_3, 4: fileroutes.health_bar_4, 5: fileroutes.health_bar_5,
            6: fileroutes.health_bar_6, 7:fileroutes.health_bar_7}

def random_descrip(b,c,d):

    num=random.choice(range(1,51))
    if num in (10,20,30,40,50):
        num_dict={10:fileroutes.random_descrip1, 20:fileroutes.random_descrip2, 30:fileroutes.random_descrip3,
                  40:fileroutes.random_descrip4, 50:fileroutes.random_descrip5}
        b.insert(tk.END, '\n\n'+num_dict[num]+' ')

def try_inventory(b,c,d):

    if 'inventory' in (c,d):
        b.insert(tk.END,"Your inventory can be seen just above this textbox.")

def coin_clear():

    for i in inventory:
        if 'Coin x' in i:
            inventory.remove(i)

def jewel_clear():

    for i in inventory:
        if 'Jewel x' in i:
            inventory.remove(i)

def jewel_decrease():

    if 'Jewel' in inventory:
        inventory.remove('Jewel')
    if 'jewel' in inventory_lower:
        inventory_lower.remove('jewel')
        if inventory_lower.count('jewel') == 1:
            inventory.append('Jewel')
        if inventory_lower.count('jewel')>1:
            inventory.append('Jewel x'+str(inventory_lower.count('jewel')))

def coin_decrease():

    if 'Coin' in inventory:
        inventory.remove('Coin')
    if 'coin' in inventory_lower:
        inventory_lower.remove('coin')
        if inventory_lower.count('coin') == 1:
            inventory.append('Coin')
        if inventory_lower.count('coin')>1:
            for i in inventory:
                if 'Coin x' in i:
                    inventory.remove(i)
                if i=='Coin':
                    inventory.remove(i)
            inventory.append('Coin x'+str(inventory_lower.count('coin')))

#textbox, action, item
def instructions(b,c,d):

    if 'instructions' in (c,d) or 'i' in (c,d):

        b.insert(tk.END, fileroutes.instructions)

#textbox, action, item
def look(b,c,d):

    directions=['n','s','w','e','north','south','east','west']

    if len(str(c))==1 and d==' ':
        b.insert(tk.END, "look\n\n")

    if c in ('l','look') and d not in directions:

        def room1(b):

            b.insert(tk.END, fileroutes.start_look_around_text)

            if door1==[]:

                b.insert(tk.END, "The door is currently closed.")

            if door1!=[]:

                b.insert(tk.END, "The door is currently open.")

        def hallwayM(b):

            b.insert(tk.END, fileroutes.hallway)

        def hallwayL(b):

            b.insert(tk.END, fileroutes.hallwayL)

        def hallwayR(b):

            b.insert(tk.END, fileroutes.hallwayR)

        def westhall(b):

            def wsound(b):

                b.insert(tk.END, fileroutes.left_hall_look)

            def nosound(b):

                b.insert(tk.END, fileroutes.left_hall_look_nosound)

            sound_dict={'present':wsound, 'gone':nosound}
            sound_dict[sound](b)

        def easthallmonster(b):

            b.insert(tk.END, fileroutes.monster_encounter[29:])

        def easthall(b):

            if torch==['unlit']:

                b.insert(tk.END, fileroutes.empty_6_turned)

            elif torch!=['unlit']:

                b.insert(tk.END, fileroutes.empty_hall_notorch)

        def basement(b):

            b.insert(tk.END, fileroutes.sewer_look)

        def guardroom(b):

            if guard:
                b.insert(tk.END, fileroutes.guard_room_guard)
            else:
                b.insert(tk.END, fileroutes.guard_room_noguard)

        def backhall(b):

            response_dict = {'alive': fileroutes.backhall_w_man, 'dead': fileroutes.backhall_noman,
                             'gone': fileroutes.backhall_man_left}
            b.insert(tk.END, response_dict[big_man[0]])

        def uphallM(b):

            b.insert(tk.END, fileroutes.exit_choice)

        def uphallR(b):

            b.insert(tk.END, fileroutes.exit_choice[83:201])

        def uphallL(b):

            b.insert(tk.END, fileroutes.exit_choice[201:])

        def statue_room(b):

            add_dict = {1: " In the statue's left eye is a shiny jewel.",
                        2: " In the statue's bottom two eyes are a pair of shiny jewels.",
                        3: " The statue's three eye sockets are shiny jewels."}
            try:
                b.insert(tk.END, fileroutes.statue+add_dict[statue_jewels])
            except KeyError:
                b.insert(tk.END, fileroutes.statue)

        look_dict={'UphallLeft':uphallL, 'UphallMiddle':uphallM, 'UphallRight':uphallR, 'Backhall':backhall, 'Guardroom':guardroom,
                   'Basement':basement, 'Easthall':easthall, 'EasthallMonster':easthallmonster, 'Westhall':westhall,
                   'HallwayRight':hallwayR, 'HallwayLeft':hallwayL, 'Room1':room1, 'HallwayMiddle':hallwayM, 'Dark Room':statue_room}
        look_dict[location](b)

#textbox, action, item
def direction(b,c,d):

    directions=['n','s','w','e','north','south','east','west']
    b.configure(state='normal')
    button_press=False

    if len(str(c))==1 and d==' ':

        b.insert(tk.END, '\n\n')
        button_press=True

    def north(b):

        def room_one(b):

            if door1==[]:
                b.insert(tk.END, "The closed door blocks your way.")
            else:
                global location
                location='HallwayMiddle'
                b.insert(tk.END, fileroutes.hallway)
                if max(minimap_counter)==1:
                    minimap_counter.append(2)

        def hallwayM(b):

            b.insert(tk.END, "There is only a hard wall to the north.")

        def westhall(b):

            global westhall_north
            global location
            global health
            if sound=='present':
                b.insert(tk.END, "When you try to move, the whispers become more intense and seem to surround you, as if trying to tell you something.")
            else:
                if westhall_north:
                    if guard:
                        if max(minimap_counter) in (3,4):
                            minimap_counter.append(max(minimap_counter)+1)
                        location='Guardroom'
                        health-=2
                        b.insert(tk.END, fileroutes.river_ride+" ")
                        b.insert(tk.END, fileroutes.guard_river_convo)
                    else:
                        b.insert(tk.END, "The water is freezing and flowing rapidly into the darkness. It seems best to leave it alone.")
                else:
                    westhall_north=True
                    if guard:
                        b.insert(tk.END, "The river is cold and moving fast, flowing away into the darkness. "+
                                 "You can go this way, but be warned that it looks hazardous.")
                    else:
                        b.insert(tk.END, "The water is freezing and flowing rapidly into the darkness. It seems best to leave it alone.")

        def easthallmonster(b):

            b.insert(tk.END, "The monster blocks your path!")

        def basement(b):

            global location
            location=before_basement[0]
            b.insert(tk.END, "You return up the stairs.")

        def easthall(b):

            global monster
            monster=False
            if door_guardroom[0]=='closed':
                b.insert(tk.END, "The north door is closed.")
            else:
                if 'Torch(lit)' in inventory:
                    inventory.remove('Torch(lit)')
                    inventory_lower.remove('torch(lit)')
                    torch.clear()
                    torch_dict = {True: 'taken', False: 'notorch_open'}
                    torch.append(torch_dict[door_easthall])
                    b.insert(tk.END, "What little fuel your torch had to offer runs out.\n")
                if sound=='present':
                    if max(minimap_counter)==3:
                        minimap_counter.append(max(minimap_counter)+1)
                if sound!='present':
                    if max(minimap_counter)==4:
                        minimap_counter.append(max(minimap_counter)+1)

                global location
                location='Guardroom'
                monster=False
                b.insert(tk.END, "You step into the north room.")

        def guardroom(b):

            b.insert(tk.END, "There is only a hard wall to the north.")

        def uphallM(b):

            global location
            location='UphallRight'
            b.insert(tk.END, fileroutes.exit_choice[83:201])

        def uphallR(b):

            global location
            location='North Tunnel'
            b.insert(tk.END, fileroutes.valley[0:166])

        def statue_room(b):

            global location
            location='UphallMiddle'
            b.insert(tk.END, "You step back into the hallway.")

        room={'UphallRight':uphallR, 'UphallMiddle':uphallM, 'UphallLeft':uphallM, 'Backhall':hallwayM, 'Guardroom':guardroom,
              'Basement':basement, 'Easthall':easthall, 'EasthallMonster':easthallmonster, 'Westhall':westhall,
              'HallwayRight':hallwayM, 'HallwayLeft':hallwayM, 'Room1':room_one, 'HallwayMiddle':hallwayM, 'Dark Room':statue_room}

        if button_press:
            b.insert(tk.END, "north\n\n")
        
        room[location](b)
        
    def south(b):

        def room_one(b):

            b.insert(tk.END, "There is only a hard wall to the south.")

        def hallwayM(b):
            
            global location
            location='Room1'
            b.insert(tk.END, "You step back into the small room.")

        def westhall(b):

            if sound=='present':

                b.insert(tk.END, "When you try to move, the whispers become more intense and seem to surround you, as if trying to tell you something.")

            elif sound!='present':

                global location
                before_basement.insert(0, location)
                location='Basement'
                b.insert(tk.END, fileroutes.sewer_go)

        def basement(b):

            global location
            location='South Tunnel'
            b.insert(tk.END, "You head into the tunnel. "+fileroutes.spider_attack[0:133]+" ")
            #sequence.append('south')

        def guardroom(b):

            global location
            global door_easthall
            if door_guardroom[0] in ('open', 'noguardnodoor'):
                if not monster:
                    location='Easthall'
                    b.insert(tk.END, "You step into the south room.")
                if monster:
                    minimap_counter.append(max(minimap_counter)+1)
                    door_easthall=False
                    location='EasthallMonster'
                    b.insert(tk.END, "You step into the south room.\n"+fileroutes.monster_encounter)
            else:
                b.insert(tk.END, "The south door is closed.")

        def uphallM(b):

            global location
            location='UphallLeft'
            b.insert(tk.END, fileroutes.exit_choice[201:])

        def uphallL(b):

            global location
            location='Dark Room'
            b.insert(tk.END, fileroutes.statue)
            if max(minimap_counter_two)==0:
                minimap_counter_two.append(1)

        room={'UphallRight':uphallM, 'UphallMiddle':uphallM, 'Backhall':room_one, 'Guardroom':guardroom, 'Basement':basement,
              'EasthallMonster':room_one, 'Easthall':room_one, 'Westhall':westhall, 'HallwayRight':hallwayM,
              'HallwayLeft':hallwayM, 'Room1':room_one, 'HallwayMiddle':hallwayM, 'UphallLeft':uphallL, 'Dark Room':room_one}

        if button_press:
            b.insert(tk.END, "south\n\n")
        try:
            room[location](b)
        except KeyError:
            pass

    def west(b):

        def room_one(b):

            b.insert(tk.END, "There is only a hard wall to the west.")

        def hallwayM(b):

            global location
            location='HallwayLeft'
            b.insert(tk.END, fileroutes.hallwayL)

        def hallwayL(b):

            if max(minimap_counter) in (2,3,4):
                minimap_counter.append(max(minimap_counter)+1)
            if max(minimap_counter)==5 and sound=='present':
                minimap_counter.append(max(minimap_counter) + 1)
            global location
            location='Westhall'
            
            def wsound(b):

                b.insert(tk.END, fileroutes.left_hall)

            def nosound(b):

                b.insert(tk.END, fileroutes.left_hall_nosound)
                
            sound_dict={'present':wsound, 'gone':nosound}
            sound_dict[sound](b)

        def easthallmonster(b):

            b.insert(tk.END, "You can't run now. You have to act!")

        def easthall(b):

            global monster
            if 'Torch(lit)' in inventory:
                inventory.remove('Torch(lit)')
                inventory_lower.remove('torch(lit)')
                torch.clear()
                torch_dict={True:'taken', False:'open_notorch'}
                torch.append(torch_dict[door_easthall])
                b.insert(tk.END, "What little fuel your torch had to offer runs out.\n")

            global location
            location='HallwayMiddle'
            monster=False
            b.insert(tk.END, "You step back into the hallway.")

        def guardroom(b):
            
            global location
            location='Backhall'
            b.insert(tk.END, "You cross the little bridge.")
            if max(minimap_counter)==4:
                minimap_counter.append(5)
            elif max(minimap_counter)==5:
                if sound!='present' and not monster:
                    minimap_counter.append(6)

        def backhall(b):

            global location
            if big_man[0]=='alive':
                b.insert(tk.END, "There is a comically large man blocking in your way.")
            else:
                location='UphallMiddle'
                b.insert(tk.END, "You walk up the stairs. "+fileroutes.exit_choice)

        room={'UphallRight':room_one, 'UphallLeft':room_one,'UphallMiddle':room_one, 'Backhall':backhall, 'Guardroom':guardroom,
              'Basement':room_one, 'Easthall':easthall, 'EasthallMonster':easthallmonster, 'Westhall':room_one,
              'HallwayLeft':hallwayL, 'HallwayRight':hallwayM, 'Room1':room_one, 'HallwayMiddle':hallwayM, 'Dark Room':room_one}

        if button_press:
            b.insert(tk.END, "west\n\n")
        
        room[location](b)

    def east(b):

        def room_one(b):

            b.insert(tk.END, "There is only a hard wall to the east.")

        def hallwayM(b):

            global location
            location='HallwayRight'
            b.insert(tk.END, fileroutes.hallwayR)

        def hallwayR(b):

            if max(minimap_counter) in (2,3):
                minimap_counter.append(max(minimap_counter)+1)
            monster_dict={True:'EasthallMonster', False:'Easthall'}
            text_dict={True:fileroutes.right_hall+'\n'+fileroutes.monster_encounter, False:"You go east."}
            global location
            location=monster_dict[monster]
            b.insert(tk.END, text_dict[monster])

        def westhall(b):

            if sound=='present':

                b.insert(tk.END, "When you try to move, the whispers become more intense and seem to surround you, as if trying to tell you something.")

            if sound!='present':

                global location
                location='HallwayMiddle'
                b.insert(tk.END, fileroutes.hallway)

        def easthallmonster(b):

            global health
            global location
            location='Easthall'
            health-=1
            b.insert(tk.END, fileroutes.run_alcove)
            if not door_easthall:
                torch.clear()
                if 'Torch(lit)' not in inventory:
                    torch.append('notorch_open')
                else:
                    torch.append('torch_open')

        def easthall(b):

            global health
            global location
            global monster
            before_basement.insert(0, location)
            location='Basement'
            monster=False

            if 'torch(lit)' in inventory_lower:
                
                inventory_lower.remove('torch(lit)')
                inventory.remove('Torch(lit)')
                torch.clear()
                torch.append('taken')
                b.insert(tk.END, fileroutes.go_alcove_torch)

            else:

                b.insert(tk.END, fileroutes.go_alcove_notorch)

            b.insert(tk.END, fileroutes.sewer_go)

        def basement(b):

            global location
            location='Cultist'

        def backhall(b):

            global location
            location='Guardroom'
            b.insert(tk.END, "You step back into the small room.")

        def uphallM(b):

            global location
            location='Backhall'
            b.insert(tk.END, "You go back down the stairs.")

        room={'UphallLeft':uphallM, 'UphallRight':uphallM, 'UphallMiddle':uphallM, 'Backhall':backhall, 'Guardroom':room_one,
              'Basement':basement, 'Easthall':easthall, 'EasthallMonster':easthallmonster, 'Westhall':westhall,
              'HallwayRight':hallwayR, 'HallwayMiddle':hallwayM, 'HallwayLeft':hallwayM, 'Room1':room_one, 'Dark Room':room_one}

        if button_press:
            b.insert(tk.END, "east\n\n")
        
        room[location](b)

    direction_dict={'n':north, 'north':north, 's':south, 'south':south, 'w':west, 'west':west, 'e':east, 'east':east}
    dir_check=0

    check_words=['check','examine','look','l','inspect']
    for k in check_words:
        for z in directions:
            if z in (c,d) and k in (c,d):
                cancel.append('cancel')

    if cancel:
        b.insert(tk.END, "This game works with a forced perspective, meaning that you're always looking in one direction. "
                 +"Type 'look' or press the button to look around, and type a direction to go in that direction. "
                 +"Just don't do both at the same time.")

    for i in (c,d):
        if i in directions and not cancel:
            if dir_check==0:
                dir_check+=1
                direction_dict[i](b)

    if cancel:
        cancel.clear()

    if health<=0 and button_press:
        b.insert(tk.END, "\n\n(Press Enter to continue.)")

    b.see('end')
    
#textbox, action, item
def inv_check(b,c,d):

    def apple_check(b):

        b.insert(tk.END, "It looks scrumptious.")

    def vial_check(b):

        b.insert(tk.END, "The vial's contents seem to sparkle and shimmer like water in the sun.")

    def box_check(b):
        
        inventory.remove('Box')
        inventory.append('Note')
        inventory_lower.remove('box')
        inventory_lower.append('note')
        coin_clear()

        for i in range(1,6):

            inventory.append('Coin')
            inventory_lower.append('coin')

        #money='Coins x'+str(dollars)
        #inventory.pop(0)
        #inventory.insert(0, money)
        b.insert(tk.END, fileroutes.check_box)
        
    def jewel_check(b):

        b.insert(tk.END, "It's shiny.")

    def paperclip_check(b):

        b.insert(tk.END, "It's a normal-looking paperclip.")

    def lighter_check(b):

        b.insert(tk.END, "It's an old, beat-up bic lighter. Wait... what time period does this game take place in?")

    def key_check(b):

        b.insert(tk.END, "It's a rusty key.")

    def note_check(b):

        if 'Note' in inventory:
            b.insert(tk.END, fileroutes.check_note)
            if 'Note 2' in inventory:
                b.insert(tk.END, '\n\n')
        if 'Note 2' in inventory:
            b.insert(tk.END, fileroutes.check_note_two)

    def coin_check(b):

        b.insert(tk.END, "They are old-looking gold coins.")

    def dagger_check(b):

        b.insert(tk.END, "The dagger is old and dull, but better than nothing.")

    def torch_check(b):

        if 'torch(lit)' in inventory_lower:

            b.insert(tk.END, "The torch is ancient and barely covered, but blazing nonetheless.")

        if 'torch(unlit)' in inventory_lower:

            b.insert(tk.END, "The torch is old and has hardly any wrapping on the end.")

    def lockbox_check(b):

        b.insert(tk.END, "It's locked.")

    def potion_check(b):

        b.insert(tk.END, "The liquid is gray and murky, and seems to swirl around on its own.")

    inv_dict={'apple':apple_check, 'vial':vial_check, 'potion':potion_check, 'lockbox':lockbox_check, 'torch':torch_check, 'dagger':dagger_check, 'note':note_check, 'coin':coin_check, 'coins':coin_check, 'box':box_check, 'jewel':jewel_check, 'paperclip':paperclip_check, 'lighter':lighter_check, 'key':key_check}

    try:
        
        if c in ('check','examine','open','read'):
            if d in inventory_lower+['coins','key','torch']:
                if d in inventory_lower:
                    inv_dict[d](b)
                if d=='coins':
                    if 'coin' in inventory_lower:
                        inv_dict[d](b)

    except KeyError:
        pass

#textbox, action, item
def inv_use(b,c,d):

    def use_lighter(b):

        if 'torch(unlit)' in inventory_lower:

            global monster
            global location
            global health
            inventory.remove('Torch(unlit)')
            inventory_lower.remove('torch(unlit)')
            inventory.append('Torch(lit)')
            inventory_lower.append('torch(lit)')
            torch.clear()
            b.insert(tk.END, "You light your torch")
            torch_dict={True:'lit', False:'torch_open'}
            torch.append(torch_dict[door_easthall])

            if location=='EasthallMonster':
                
                location='Easthall'
                monster=False
                health-=1
                b.insert(tk.END, " and swing it in the beast's face.")
                b.insert(tk.END, fileroutes.sad_hit)
                b.insert(tk.END, '\n\nYou lose one bar of health.')

            if location=='Easthall':

                b.insert(tk.END, ". ")

            else:

                inventory.remove('Torch(lit)')
                inventory_lower.remove('torch(lit)')
                b.insert(tk.END, ", but it's old and rotten. It flares up quickly and then falls apart. ")

        if location=='Westhall':

            b.insert(tk.END, "You strike your lighter, but the darkness seems to swallow what little light it produces. It does little to help you see.")
                
        else:
            
            b.insert(tk.END, "You strike your lighter. The room is a bit brighter. ")

    def use_torch(b):

        global health
        global location
        global monster

        if location=='EasthallMonster' and 'torch(unlit)' in inventory_lower:

            health-=2
            location='Easthall'
            monster=False
            b.insert(tk.END, "You wave it in the beast's face, but it isn't very intimidating without fire. ")
            b.insert(tk.END, fileroutes.normal_hit)
            b.insert(tk.END, '\n\nYou lose two bars of health.')

        else:

            use_lighter(b)

    def use_key(b):

        if 'lockbox' in inventory_lower:
            b.insert(tk.END, fileroutes.lockbox)
            jewel_clear()

            for i in ('key', 'lockbox'):
                inventory_lower.remove(i)
                inventory.remove(str.capitalize(i))
            for i in ('note', 'potion'):
                inventory_lower.append(i)
            inventory.append('Potion')
            inventory.append('Note 2')

        else:
            global door_easthall
            if location in ('Room1','Easthall') or (location=='Guardroom' and door_easthall and 'gold key' not in inventory_lower):
                b.insert(tk.END, "The key doesn't fit the door's lock.")
            if location=='Guardroom' and 'gold key' in inventory_lower and door_easthall:
                inventory_lower.remove('gold key')
                inventory.remove('Gold Key')
                door_easthall=False
                door_guardroom.clear()
                door_guardroom.append('noguardnodoor')
                b.insert(tk.END, "The gold key fits perfectly. As it swings open, your key snaps in the lock.")
            if location not in ('Room1','Easthall','Guardroom'):
                b.insert(tk.END, "There is nothing here to use a key on.")

    def use_vial(b):

        global health
        inventory_lower.remove('vial')
        inventory.remove('Vial')
        health+=2
        b.insert(tk.END, "The liquid is shockingly cold when it enters your mouth, yet it fills your stomach with a radiant warmth. This internal comfort... it fills you with determination.")
        b.insert(tk.END, "\n\nYou gain two bars of health.")

    def use_coin(b):

        b.insert(tk.END, "There isn't anything to use a coin on.")

    def use_jewel(b):

        global location
        global statue_jewels
        if location=='Dark Room':
            if statue_jewels<3:
                statue_jewels+=1
                jewel_clear()
                jewel_decrease()
                b.insert(tk.END, "You put a jewel up to one of the statue's eye sockets and it is sucked right in,"+
                                 " as if by an unseen force. ")
                if statue_jewels==3:
                    sequence.append('riddles')
            else:
                b.insert(tk.END, "The statue's eyes are already filled. They seem to glow slightly.")
        else:
            b.insert(tk.END, "There is nothing here to use a jewel on.")

    def use_apple(b):

        global health
        health+=1
        inventory_lower.remove('apple')
        inventory.remove('Apple')
        b.insert(tk.END, "You hadn't realized how hungry you were until just now. Having a full belly... it fills you with determination.\n\nYou gain one bar of health.")

    def use_potion(b):

        inventory_lower.remove('potion')
        inventory.remove('Potion')
        fifty_fifty=(1,2)
        effect=random.choice(fifty_fifty)

        def bad():

            global health
            health-=1
            b.insert(tk.END, "The liquid is viscous and sickeningly sweet going down. Your stomach feels... cold.\n\nYou lose one bar of health.")

        def good():

            global health
            health+=1
            b.insert(tk.END, fileroutes.potion_helps)

        effect_dict={1:bad, 2:good}
        effect_dict[effect]()

    use_dict={'apple':use_apple, 'vial':use_vial, 'potion':use_potion, 'lockbox':use_key, 'torch':use_torch, 'jewel':use_jewel,
              'coin':use_coin, 'coins':use_coin, 'lighter':use_lighter, 'key':use_key, 'jewels':use_jewel}

    try:

        if c in ('place','put','use','light','drink','unlock','eat')\
                and d in inventory_lower+['coins','torch','gold key','jewels']:
            if d in inventory_lower:
                use_dict[d](b)
            if d=='coins' and 'coin' in inventory_lower:
                use_dict[d](b)
            if d=='torch':
                if c!='light':
                    if 'torch(unlit)' in inventory_lower or 'torch(lit)' in inventory_lower:
                        use_dict[d](b)
                if c=='light':
                    use_lighter(b)
            if d=='key' and 'gold key' in inventory_lower:
                use_dict['key'](b)

    except KeyError:
        pass

def basic_functions(a,b,c):

    inv_check(a,b,c)
    inv_use(a,b,c)
    look(a,b,c)
    try_inventory(a,b,c)
    instructions(a,b,c)
    direction(a,b,c)
    random_descrip(a,b,c)

def riddles_func(a,b):

    global health
    answer1_dict = {1: ('music', 'instrument'), 2: ('9', 'nine'), 3: ('center', 'middle'), 4: ('cloud', 'storm'),
                    5: ('fire','flame','burn')}
    response1_dict = {1: ' "The men are playing music for money."',
                      2: ' "There are nine members of the family: the parents, four boys, and three girls."',
                      3: ' "With some luck, the lion may have starved to death."', 4: ' "I am a cloud."',
                      5: ' "I am a burning flame."'}
    answer2_dict={1:('skull'), 2:('dozens'), 3:('light','bulb','candle','flash','lantern','torch','fire','flame'),
                  4:('hook','bait'), 5:('anchor')}
    response2_dict={1:' "I am a skull."', 2:' "I am the word '+"'dozens'"+'."', 3:' "I am a light bulb, or perhaps a candle."',
                    4:' "I am a fish hook."', 5:' "I am an anchor."'}
    answer3_dict={1:('dictionary'), 2:('stamp','post'), 3:('well','tunnel'), 4:('mail','box'), 5:('glove')}
    response3_dict={1:' "The place is a dictionary."', 2:' "I am a stamp."', 3:' "I am a well."', 4:' "I am a mailbox."',
                    5:' "I am a pair of gloves."'}
    yes_no = False
    if a==' ':
        riddle_1=random.choice(range(1,6))
        riddle_choice.clear()
        riddle_choice.append(riddle_1)
        riddle1_dict={1:fileroutes.riddle1, 2:fileroutes.riddle2, 3:fileroutes.riddle3, 4:fileroutes.riddle4,
                      5:fileroutes.riddle5}
        b.insert(tk.END,'\n\n'+riddle1_dict[riddle_1])

    if max(riddle_count)==1:
        b.insert(tk.END, "\n\n")
        for k in answer1_dict[riddle_choice[0]]:
            if k in a:
                yes_no=True

    if max(riddle_count)==2 and health>0:
        b.insert(tk.END, "\n\n")
        for k in answer2_dict[riddle_choice[0]]:
            if k in a:
                yes_no = True

    if max(riddle_count)==3 and health>0:
        b.insert(tk.END, "\n\n")
        for k in answer3_dict[riddle_choice[0]]:
            if k in a:
                yes_no = True

    if yes_no:
        b.insert(tk.END, '"Correct", the voice says with some satisfaction.')
    if not yes_no and a!=' ':
        health-=2
        b.insert(tk.END, '"Wrong", the voice says with a hint of sadness.')
    which_riddle_dict={1:response1_dict, 2:response2_dict, 3:response3_dict}
    if health>0:
        try:
            b.insert(tk.END, which_riddle_dict[max(riddle_count)][riddle_choice[0]])
        except KeyError:
            pass
    if not yes_no and a!=' ':
        b.insert(tk.END," A terrible sensation overcomes you, like the air is being sucked from your lungs."+
                 " The feeling after could best be described as... hollow. You lose two bars of health.")

    riddle_count.append(max(riddle_count)+1)

    if max(riddle_count)==2 and health>0:
        riddle_2=random.choice(range(1,6))
        riddle_choice.clear()
        riddle_choice.append(riddle_2)
        riddle2_dict = {1: fileroutes.riddle6, 2: fileroutes.riddle7, 3: fileroutes.riddle8, 4: fileroutes.riddle9,
                        5: fileroutes.riddle10}
        b.insert(tk.END, '\n\n' + riddle2_dict[riddle_2])

    if max(riddle_count)==3 and health>0:
        riddle_choice.clear()
        riddle_3=random.choice(range(1,6))
        riddle_choice.clear()
        riddle_choice.append(riddle_3)
        riddle3_dict={1:fileroutes.riddle11, 2:fileroutes.riddle12, 3:fileroutes.riddle13, 4:fileroutes.riddle14,
                      5:fileroutes.riddle15}
        b.insert(tk.END, '\n\n'+riddle3_dict[riddle_3])

