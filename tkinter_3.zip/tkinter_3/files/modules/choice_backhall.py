import tkinter as tk
from tkinter import ttk
import files.modules.values as values
import files.modules.fileroutes as fileroutes

items_backhall=['man','guard','guy','floor','wall','walls','ceiling']
man_words=['man','guard','guy']
talk=[]

def big_man_fight(b,c,d):

    weapon=0
    values.big_man.clear()
    values.big_man.append('dead')
    for m in (items_backhall, man_words):
        m.append('body')
        m.append('corpse')
    for i in values.inventory_lower:
        if i in ('dagger','sword'):
            weapon+=values.weapon_dict[i]
    attack_dict = {0: "You try to punch him, but only hurt your hand. ",
                   1: "You cut him with your dagger and he is utterly unfazed. ",
                   2: "You cut him with your dagger and he is utterly unfazed. ",
                   3: "You cut him with your dagger and he is utterly unfazed. ",
                   4: "You cut him with your sword and he is utterly unfazed. ",
                   5: "You cut him with your sword and he is utterly unfazed. "}
    health_loss = {0: 3, 1: 2, 2: 2, 3: 1, 4: 1, 5: 1}
    values.health-=health_loss[weapon]
    b.insert(tk.END, attack_dict[weapon])
    b.insert(tk.END, fileroutes.big_man_fight)
    if weapon<3:
        b.insert(tk.END, " He then proceeds to toss you around like a ragdoll. You flail around so violently that a foot" +
                 " eventually finds his crotch, ending the fight but leaving you much worse for wear.")
    else:
        b.insert(tk.END, " He then proceeds to beat you up, but a sword is a sword. You eventually defeat him.")
    b.insert(tk.END, "\n\nYou lose "+str(health_loss[weapon])+" bars of health.")

def choice_backhall(b,c,d):

    if c in ('talk','speak','say'):
        if 'uniform' not in values.inventory_lower:
            if not talk:
                talk.append('talk')
                b.insert(tk.END, fileroutes.big_man_talk)
            else:
                b.insert(tk.END, 'The man just shakes his head. "Take your questions to Frank, I don'+"'t know nothin'."+'"')
        else:
            values.big_man.clear()
            values.big_man.append('gone')
            for x in man_words:
                items_backhall.remove(x)
            b.insert(tk.END, fileroutes.big_man_talk_uniform)

    if c in ('give','pay'):
        if values.big_man[0]=='alive':
            if d in ('toll','coin','coins','man','guard','guy','gold',''):
                if values.inventory_lower.count('coin')>=15:
                    values.big_man.clear()
                    values.big_man.append('gone')
                    for z in man_words:
                        items_backhall.remove(z)
                    for i in range(1,16):
                        values.coin_clear()
                        values.coin_decrease()
                    b.insert(tk.END, "The man takes your money and plods off without a word. He seems displeased.")
                else:
                    b.insert(tk.END, "You don't have enough money!")
            if d=='jewel' and 'jewel' in values.inventory_lower:
                b.insert(tk.END, "He looks at it and vigorously shakes his head."+' "You could'+"n't pay me enough to take"+
                         ' that cursed thing".')
        else:
            if values.big_man[0]=='dead':
                b.insert(tk.END, "He won't need your money any time soon.")
            else:
                b.insert(tk.END, "There is no one here to pay!")

    if d in items_backhall+['']:

        if c in ('hit','punch','kill','attack','fight','kick'):
            if d in man_words+['']:
                big_man_fight(b,c,d)
            else:
                for h in ('kill','attack','fight'):
                    if c==h:
                        c='hit'
                b.insert(tk.END, "You "+c+" it and hurt your hand. You lose one bar of health.")

        if c in ('check','examine','inspect','search'):
            if d in man_words:
                if values.big_man[0]=='dead':
                    b.insert(tk.END, "You search the man's slumped body. His pockets are strangely empty.")
                else:
                    b.insert(tk.END, "He is a comically large man blocking your path.")
            if d in ('floor','wall','walls','ceiling'):
                if d=='ceiling':
                    items_backhall.append('jewel')
                    items_backhall.remove('ceiling')
                    b.insert(tk.END, "You "+c+" the ceiling and spy something shiny lodged into the brick.")
                else:
                    b.insert(tk.END, "You "+c+" the "+d+" and find nothing of significance.")
            if d=='jewel':
                b.insert(tk.END, "It is lodged precariously in the bricks above your head.")

        if c in ('take','grab','get') and d=='jewel':
            values.jewel_clear()
            items_backhall.remove('jewel')
            values.inventory_lower.append('jewel')
            values.inventory.append('Jewel')
            b.insert(tk.END, "You stand up on your tip-toes and pluck the jewel from the ceiling.")
