Author:
Robert Finn
14finnr@gmail.com

Thank you for downloading my humble game!

IMPORTANT

Installation:

If you got these files from GitHub, make sure to place the 'modules', 'images', and 'notepad_files' folders
together in a folder called 'files'. Then simply put the 'files' folder in the same directory as the game.
Do the same if your copy of the game isn't working for any reason.

Instructions and Gameplay Tips:

This game uses buttons for some of the most common inputs. It's very important to remember that while 
the buttons are a voluntary mechanic that the player can ignore, the input field is absolutely not voluntary 
and it will be the primary way that any player interacts with the game world.
In addition, many players see the commands on the buttons (north south east west look) as well as
'check' (explained on the start page) and assume that those are the only commands. Don't feel railroaded by
the most common inputs. There are dozens of commands that can make an action happen in-game. Experiment.



UNIMPORTANT


Development Info:

This project has been ongoing, in one form or another, since November 2018 when it began its life as a
Computer Science 101 project, which looked like an incomplete, buggy text game that ran in the windows 
command line. It earned me a very generous C.

The present version was written in Python 3.7.2 using the tkinter GUI and is documented on GitHub. 
If for whatever reason you are interested in seeing the source code, just reach out and I will provide you
with the permissions necessary to view the files.



Author Notes:

I made this game because I absolutely adore the format of the classic text games of the 70s and 80s, as
well as the content created by the modern-day Interactive Fiction community. However, when I try to play these 
games for any extended period of time I inevitably lose interest after spending
too much time wandering from empty room to empty room and causing seemingly unimportant events to occur
within the game world. I love the format, but the games themselves just aren't for me. So around the end of 2018
I set out to create a text-based adventure in a format that a player like myself would find more approachable 
than traditional IF games. That meant adding all the bells and whistles in the form of a compass,
visible health/inventory, room graphics, and scripted events with choices presented by buttons.
It also meant that I wanted to avoid any lull in the player's engagement. There are no empty rooms in
this game. Every room (with the exception of the first one) has at least one obvious feature to interact with,
usually in the form of an NPC, and each of those interactions can have major consequences for the player's 
story. It's my hope that it will offer the kind of experience I always wanted from a text adventure.
Please enjoy, and don't be afraid to criticize.